# SRT Web App — User Guide

Stock Reconciliation Tracking (SRT) mobile web app for creating, submitting, and approving stock reconciliation records.

---

## Getting Started

1. Open the web app URL shared by your admin
2. Enter your **Email** and **Password** (same as your Frappe/ERPNext login)
3. Tap **Sign In**

Your session stays active until you log out or it expires. If you see "Session expired", log in again.

### Add to Home Screen (optional)

For a native app feel:

- **iPhone**: Open in Safari > tap Share > "Add to Home Screen"
- **Android**: Open in Chrome > tap Menu (3 dots) > "Add to Home Screen"

---

## Navigation

The app has 3 pages, accessible from the bottom navigation bar:

| Tab | Icon | Purpose |
|-----|------|---------|
| **Dashboard** | Grid | View pending approvals (Admin / Super Admin) |
| **New SRT** | Plus | Create a new Stock Reconciliation |
| **History** | Clock | View past SRT records and their status |

The **Logout** button (door icon) is at the top-right corner.

---

## For Users (Srt User Role)

### Creating a New SRT

1. Tap **New SRT** in the bottom nav

2. **Select Item**
   - Start typing the item code or name in the search box
   - A dropdown appears with matching items (format: `ITEM-CODE : Item Name`)
   - Tap to select

3. **Select Warehouse**
   - Start typing the warehouse name
   - Tap to select from the dropdown

4. **Set Posting Date & Time**
   - Defaults to today's date and current time
   - Change if you're recording a count done at a different time
   - The stock snapshot is taken as of this date/time

5. **Batch Cards Auto-Populate**
   - All batches with positive stock (as of the posting date/time) appear automatically
   - Each card shows:
     - **Batch Number**
     - **Current Stock** (in the selected UOM — snapshot at posting date/time)
     - **Qty Found** (input field — disabled until you tick Reconcile)
     - **Stock UOM Qty** and **Conversion Factor** (read-only)

6. **Tick "Reconcile" and Enter Qty Found**
   - Tick the **Reconcile** checkbox on each batch you physically counted
   - Enter the **Qty Found** — the quantity you actually found on the floor
   - Unticked batches are treated as "not counted" — their current stock carries forward as-is

7. **Adding Batches Not Listed (0 Stock)**
   - Below the batch cards, find the **"Add Batch (0 stock / not listed)"** section
   - Search for any batch of the selected item by typing the batch number
   - Batches already in the list are excluded from results
   - Tap a batch to add it — it appears in the batch list with "Reconcile" pre-ticked and current stock = 0
   - Use this when you physically found stock for a batch that the system shows as 0

8. **Totals Panel**
   - Updates live as you tick batches and enter quantities:
     - **Current Stock** — total system stock (all batches, in default UOM)
     - **Actually Found** — total physical count (in default UOM)
     - **Delta** — difference between found and current (green if +, red if -)
   - Also shows the same in higher UOM (e.g., Kg vs Gm)

9. **User Remark** (required for submit)
   - Enter a note explaining why you're doing this reconciliation
   - This remark is visible to Admin during approval

10. **Save or Submit**
    - **Save as Draft** — saves your work, you can come back and edit later
    - **Save & Submit** — saves and submits for approval
    - You must tick at least one batch and fill the User Remark to submit

### What Happens After Submit?

- **Case 1 (Auto-Approve)**: If ALL ticked batches have Qty Found = Current Stock (no difference), the system auto-approves it instantly. You'll see a toast: "All batches matched — Auto-Approved by System!"
- **Case 2 (Manual Approval)**: If there's any difference, the SRT goes to the Admin for approval. Status changes to "Draft" (pending Admin approval).

---

## For Admins (Srt Admin Role)

### Dashboard — Admin Approval Tab

1. Tap **Dashboard** in the bottom nav
2. The **Admin** tab shows all SRTs pending your approval
3. The badge number shows the count of pending items

### Understanding the Approval Cards

Each card shows:

| Field | Description |
|-------|-------------|
| **Item : Item Name** | Which item was reconciled |
| **SRT Name** | The document ID (e.g., SRT-RECO-2026-00003) |
| **Warehouse** | Where the count was done |
| **Snapshot Stock** | System stock at the posting date/time |
| **Physical Found** | What the user actually counted |
| **Difference** | The gap — shown in **green** if positive (e.g., +904), in **red** if negative (e.g., -323) |
| **Date** | Posting date |

### Viewing SRT Details

1. Tap any card or the **View** button
2. A modal opens showing:
   - Full totals (Snapshot Stock vs Physical Found + Difference)
   - **User Remark** — what the user wrote when submitting
   - Each batch with Current vs Found quantities
   - Counted batches are highlighted; uncounted are dimmed

### Approving an SRT

1. Open the SRT detail modal
2. Read the User Remark and review the batches
3. Enter your **Admin Remark** (required)
4. Tap **Approve**

### Rejecting an SRT

1. Open the SRT detail modal
2. Enter your **Admin Remark** (required — explain why you're rejecting)
3. Tap **Reject**
4. The SRT goes back to the user as "Closed" (rejected)

### Bulk Approve

1. On the dashboard, tick the checkboxes on multiple cards
2. Use **Select All** to select everything
3. The bulk action bar appears at the bottom: "X selected — Approve All"
4. Tap **Approve All**
5. Enter a remark (required for all selected)
6. All selected SRTs are approved at once

### What Admin Can See

- **User Remark** — always visible when viewing an SRT
- **Admin Remark** — only visible to Super Admin (not to the user or other admins)

---

## For Super Admins (Srt Super Admin Role)

### Dashboard — Super Admin Approval Tab

1. Tap **Dashboard** in the bottom nav
2. Switch to the **Super Admin** tab
3. These are SRTs that have already been approved by Admin and need your final approval

### Viewing SRT Details

Same as Admin view, but you can see:

- **User Remark** — what the user wrote
- **Admin Remark** — what the admin wrote during their approval

### Approving (Final Approval)

1. Open the SRT detail modal
2. Review User Remark + Admin Remark + batch details
3. Enter your **Super Admin Remark** (required)
4. Tap **Approve**
5. This triggers the final stock reconciliation in ERPNext — the system stock is updated

### Rejecting

Same as Admin rejection — enter a remark and tap Reject.

### Bulk Approve

Same as Admin — select multiple cards and tap "Approve All".

### What Super Admin Can See

- **User Remark** — always visible
- **Admin Remark** — visible (to understand admin's reasoning)
- **Super Admin Remark** — only stored for audit trail

---

## History

1. Tap **History** in the bottom nav
2. Shows all your past SRT records (Admins/Super Admins see all users' records)
3. Each card shows: Item, SRT Name, Warehouse, Date, and Status

### Status Meanings

| Status | Meaning |
|--------|---------|
| **Draft** | Submitted, waiting for Admin approval |
| **Admin Approved** | Admin approved, waiting for Super Admin |
| **Completed** | Super Admin approved, stock updated in ERPNext |
| **Auto-Approved** | System auto-approved (all batches matched) |
| **Closed** | Rejected by Admin or Super Admin |
| **Cancelled** | Document was cancelled |

Tap any history card to view the full detail modal.

---

## Understanding the Numbers

### Snapshot Stock vs Physical Found

- **Snapshot Stock** = what the system says the stock is, as of the posting date and time
- **Physical Found** = what was actually counted on the warehouse floor

### Difference (Delta)

- **Green (e.g., +904)** = you found MORE than the system expected — surplus
- **Red (e.g., -323)** = you found LESS than the system expected — shortage
- **Green 0** = exact match — no discrepancy

### UOM and Conversion

- Items may have two UOMs (e.g., Gm as stock UOM, Kg as higher UOM)
- The batch cards show quantities in the higher UOM (e.g., 2.5 Kg)
- The totals panel shows both UOMs
- Conversion is automatic (e.g., 1 Kg = 1000 Gm)

### Counted vs Uncounted Batches

- **Counted** (Reconcile ticked) = you physically counted this batch. The Qty Found you entered is used.
- **Uncounted** (Reconcile not ticked) = you did NOT count this batch. The system assumes Current Stock = Found (no change).

---

## Remarks — Who Sees What

| Remark | Written By | Visible To |
|--------|-----------|------------|
| **User Remark** | SRT User (at submit) | Admin, Super Admin |
| **Admin Remark** | Admin (at approve/reject) | Super Admin only |
| **Super Admin Remark** | Super Admin (at approve/reject) | Audit trail only |

All remarks are **mandatory** — you cannot submit, approve, or reject without entering a remark.

---

## Troubleshooting

| Problem | Solution |
|---------|----------|
| "Session expired" | Log out and log in again |
| Login fails | Check your email/password — same as Frappe desk login |
| No batches appear after selecting item + warehouse | The item has no stock at that posting date/time. Use "Add Batch" to manually add batches. |
| "Add Batch" shows no results | The item may not have any batches at all in the system, or you've already added them all |
| Dropdown doesn't appear | Type at least 2 characters for item/warehouse, or 1 character for batch search |
| Can't submit | Make sure: (1) at least one batch has Reconcile ticked, (2) User Remark is filled |
| Can't approve/reject | Make sure the remark field is filled — it's required |
| Dashboard shows 0 pending | All SRTs have been processed — check History for past records |
| "Approve All" doesn't work | Select at least one card using the checkboxes first |
| Toast says "API error" | The error message comes from Frappe — read it for details (e.g., missing field, permission issue) |
