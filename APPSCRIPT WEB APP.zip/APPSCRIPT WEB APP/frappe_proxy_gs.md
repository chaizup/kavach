# FrappeProxy.gs — Frappe API Proxy

> **Sync-block v0.0.1** — last verified against `FrappeProxy.gs` on 2026-06-12

## Purpose
All Frappe API calls routed through the stored `sid` cookie. Client JS calls these via `google.script.run.<functionName>()`.

## Internal Helpers

| Function | Line | Description |
|---|---|---|
| `_getSid()` | 23 | Reads `frappe_sid` from `UserProperties`. Throws `SESSION_EXPIRED` if missing. |
| `_getUserFrappeUrl()` | 29 | Delegates to `getFrappeUrl()` in Code.gs. |
| `_frappeGet(path, params, sid)` | 33 | GET request with `Cookie: sid=<sid>`. URL-encodes params. Throws `SESSION_EXPIRED` on 401/403. |
| `_frappePost(path, data, sid)` | 53 | POST request with JSON body. Fetches CSRF token first via `frappe.auth.get_csrf_token`. Parses `_server_messages` on error. |

## Login (with URL)

| Function | Line | Description |
|---|---|---|
| `loginWithUrl(frappeUrl, email, password)` | 111 | Alternative login that accepts user-provided Frappe URL. Normalizes URL, stores in `UserProperties`, extracts sid, fetches user info + roles. |

## Dashboard Endpoints

| Function | Line | Frappe Method | Description |
|---|---|---|---|
| `getDashboardRows(tab, itemFilter)` | 188 | `srt_dashboard.get_dashboard_rows` | Rows for Admin/Super Admin tabs |
| `getDashboardCounts()` | 194 | `srt_dashboard.get_dashboard_counts` | Badge counts per tab |
| `getBatchSummary(srtName)` | 198 | `srt_dashboard.get_batch_summary` | Enriched batch data for view modal |
| `getBatchDrilldown(...)` | 203 | `srt_dashboard.get_batch_drilldown` | Batch transaction drilldown |

## Form CRUD

| Function | Line | Frappe Method | Description |
|---|---|---|---|
| `getFormMeta()` | 215 | `srt_dashboard.get_form_meta` | Roles, defaults, field options |
| `loadSrtForm(name)` | 219 | `srt_dashboard.load_srt_form` | Load Draft SRT for editing (rejects non-Draft) |
| `getSrtDoc(name)` | 229 | `frappe.client.get` | Read-only fetch of any SRT (any docstatus) — used by View modal |
| `saveSrtForm(payload, name)` | 237 | `srt_dashboard.save_srt_form` | Create or update Draft SRT |
| `submitSrtForm(name)` | 243 | `srt_dashboard.submit_srt_form` | Submit Draft → triggers workflow |

## Workflow Actions

| Function | Line | Frappe Method | Description |
|---|---|---|---|
| `approveSrt(srtName, remark)` | 253 | `srt_dashboard.approve_srt` | Approve (Admin or Super Admin) |
| `rejectSrt(srtName, reason)` | 259 | `srt_dashboard.reject_srt` | Reject with reason |
| `bulkApproveSrt(srtNames, bulkRemark)` | 264 | `srt_dashboard.bulk_approve_srt` | Batch approve multiple SRTs |

## Item / Warehouse Search

| Function | Line | Frappe Method | Description |
|---|---|---|---|
| `getItemDefaults(itemCode, warehouse, postingDate, postingTime)` | 277 | `kavach...api.get_item_defaults` | Item UOM, batches, stock data |
| `searchItems(txt)` | 285 | `frappe.client.get_list` (POST) | Items with `has_batch_no=1`, or_filters on name/item_name |
| `searchWarehouses(txt)` | 302 | `frappe.client.get_list` (POST) | Non-group warehouses, or_filters on name |

## Batch Search (Add Batch — 0-stock batches)

| Function | Line | Frappe Method | Description |
|---|---|---|---|
| `searchBatches(itemCode, txt)` | — | `frappe.client.get_list` (POST) | All non-disabled batches for item, including 0-stock. Filters by name LIKE. |
| `getBatchCurrentState(itemCode, batchNo, postingDate, postingTime)` | — | `kavach...api.get_batch_current_state` | Returns `{qty, warehouse, valuation_rate, stock_uom}` for a single batch at posting date/time. Returns qty=0 for 0-stock batches. |

## History

| Function | Line | Frappe Method | Description |
|---|---|---|---|
| `getSrtHistory(pageLength, start)` | — | `frappe.client.get_list` (POST) | User's own SRTs, ordered by creation desc |
| `getAllSrtHistory(pageLength, start)` | — | `frappe.client.get_list` (POST) | All SRTs (for admin/super admin view) |

## Important Notes
- Search functions use `POST /api/method/frappe.client.get_list` (not `GET /api/resource/`) because Frappe's REST endpoint unreliably handles `or_filters` as URL parameters
- `getSrtDoc` uses `frappe.client.get` for read-only access — no docstatus restriction (unlike `loadSrtForm`)
- CSRF token is fetched before every POST request via `frappe.auth.get_csrf_token`
- `_server_messages` are double-JSON-encoded by Frappe: `JSON.parse(body._server_messages)` → array of JSON strings → each parsed for `.message`

## Dependencies
- Calls: `getFrappeUrl()` (Code.gs), `UrlFetchApp` (GAS built-in)
- Called by: `script.html` via `google.script.run`, `Auth.gs` (login helpers)
