# script.html — SPA Client-Side JavaScript

> **Sync-block v0.0.1** — last verified against `script.html` on 2026-06-12

## Purpose
Single-Page Application (SPA) logic for the SRT Web App. Handles login, dashboard, form, history, view modal, and all user interactions. Communicates with Frappe via `google.script.run` → GAS server → Frappe API.

## Sections Overview (1137 lines)

| Section | Lines | Description |
|---|---|---|
| §1 Utils | 18–52 | `callServer()` Promise wrapper, formatters, `debounce` |
| §2 State | 59–92 | `App` global state object, role helpers |
| §3 Toast | 100–107 | `showToast(msg, type, duration)` |
| §4 Modal | 114–130 | `showModal(html)` / `closeModal()`, overlay click handler |
| §5 Router | 137–155 | `navigateTo(page)` — switches dashboard/create/history |
| §6 Login | 162–198 | Login form handler, calls `Auth.gs login()` |
| §7 App Init | 205–242 | Session check, bottom nav wiring, logout, boot sequence |
| §8 Dashboard | 249–491 | Tabs, card list, select-all, bulk approve, status pills |
| §9 View Detail | 498–597 | Modal with batches, remarks, approve/reject buttons |
| §10 Create Form | 651–1072 | Item/warehouse search, batch cards, totals, save/submit |
| §11 History | 1079–1136 | Past SRTs list with status pills |

## §1. Utils (lines 18–52)

### `callServer(fn, ...args)` — Line 18
Promise wrapper around `google.script.run`:
```
google.script.run
  .withSuccessHandler(resolve)
  .withFailureHandler(reject)
  [fn](...args)
```

### Formatters
| Function | Line | Purpose |
|---|---|---|
| `fmtNum(v, precision)` | 30 | Indian locale formatting (`en-IN`), default 3 decimal places |
| `fmtDate(d)` | 38 | `DD MMM YYYY` format via `en-IN` locale |
| `escHtml(s)` | 44 | XSS-safe HTML escaping via `textContent` → `innerHTML` |
| `debounce(fn, ms)` | 50 | Standard debounce, used for search inputs (300ms) |

## §2. State (lines 59–92)

### `App` Object
```javascript
{
  user: { email, fullName, roles },
  currentPage: 'dashboard' | 'create' | 'history',
  dashboard: { tab, rows[], counts{}, selected: Set, loading },
  form: { item, item_name, default_warehouse, posting_date, posting_time,
          default_uom, higher_uom, higher_uom_cf, totals..., batches[], company,
          name, modified, user_remark },
  history: { rows[], loading }
}
```

### Role Helpers
| Function | Line | Description |
|---|---|---|
| `hasRole(role)` | 84 | Checks `App.user.roles.includes(role)` |
| `isAdmin()` | 87 | `Srt Admin` OR `System Manager` OR `Administrator` |
| `isSuperAdmin()` | 90 | `Srt Super Admin` OR `System Manager` OR `Administrator` |

## §5. Router (lines 137–155)

`navigateTo(page)`:
1. Updates `App.currentPage`
2. Toggles `.active` on bottom nav items
3. Sets top bar title
4. Clears content area with spinner
5. Calls `renderDashboard()` / `renderCreateForm()` / `renderHistory()`

## §6. Login (lines 162–198)

- URL field hidden by default (`$('#url-field-wrap').style.display = 'none'`)
- Calls `login(email, pwd)` from Auth.gs
- On success: sets `App.user`, calls `showApp()`

## §7. Boot Sequence (lines 228–242)

```
DOMContentLoaded → initLogin() → callServer('checkSession')
  → loggedIn?  → showApp() → navigateTo('dashboard')
  → !loggedIn? → showPage('page-login')
```

## §8. Dashboard (lines 249–491)

### Tabs
- Always shows both tabs: "Admin Approval Pending" and "Super Admin Approval Pending"
- Server-side `get_dashboard_rows` handles permission filtering
- Tab badges show counts from `getDashboardCounts()`

### Card Rendering
Each card shows:
- Item code : Item name (truncated)
- SRT name + warehouse
- Current stock vs Found (with delta coloring)
- Date + View button
- Checkbox (for admins, for bulk select)

### Bulk Approve
- Select-all checkbox + per-card checkboxes
- Bulk bar appears with count + "Approve All" button
- Calls `bulkApproveSrt(names, remark)` then refreshes

### `statusPill(state)` — Line 481
Maps workflow states to pill classes:
| State | CSS Class | Label |
|---|---|---|
| Draft | `pill-draft` | Draft |
| Admin Approval | `pill-admin` | Admin Approved |
| Super Admin Approval | `pill-super` | Completed |
| Approved By System | `pill-system` | Auto-Approved |
| Close | `pill-close` | Closed |

## §9. View SRT Detail (lines 498–597)

### `viewSrt(name)` — Line 498
1. Shows loading spinner in modal
2. Fetches in parallel: `getSrtDoc(name)` + `getBatchSummary(name)`
3. Determines approve/reject permissions from `workflow_state` + user role
4. Renders: item info, totals panel, remarks, batch cards (with counted/uncounted styling), approve/reject buttons

**Key:** Uses `getSrtDoc` (not `loadSrtForm`) — works for any docstatus (Draft, Submitted, Cancelled).

### `approveFromModal(name)` — Line 599
Calls `approveSrt(name, remark)`, refreshes dashboard on success.

### `rejectFromModal(name)` — Line 622
Prompts for required rejection reason, calls `rejectSrt(name, reason)`.

## §10. Create SRT Form (lines 651–1072)

### Flow
1. `renderCreateForm()` — resets form state, renders inputs
2. `bindFormSearch()` — wires item/warehouse autocomplete (debounced 300ms)
3. User selects item → selects warehouse → `tryLoadBatches()`
4. `tryLoadBatches()` → calls `getItemDefaults()` → populates `App.form.batches[]`
5. `renderFormBatches()` — renders batch cards with checkbox + qty input
6. User ticks "Reconcile" / enters qty → `recomputeFormTotals()`
7. Save or Submit

### Item/Warehouse Search
- Display format: `<item_code> : <item_name>` (items) / `<warehouse_name>` (warehouses)
- Dropdown: `search-results` div, absolute positioned
- Auto-close on outside click

### Batch Cards
Each card shows:
- Batch number + "Reconcile" checkbox
- Current stock (in selected UOM)
- Qty Found input (disabled until checkbox ticked)
- Stock UOM Qty + Conversion Factor (read-only)

### Add Batch (0-stock / not auto-populated)
- "Add Batch" search input appears below batch cards after batches load
- Searches all non-disabled batches for the selected item via `searchBatches()`
- Already-added batches are filtered out from results
- On selection: calls `getBatchCurrentState()` to get stock qty (may be 0), builds batch row with same UOM/CF as auto-populated batches, adds with `is_counted: 1` pre-ticked
- Recomputes totals and re-renders batch list

### `recomputeFormTotals()`
- Iterates all batches
- Counted rows: `qty_found × conversion_factor` → sum to total found
- Uncounted rows: `current_stock_in_stock_uom` → contribute to total found
- Higher UOM totals: divide by `higher_uom_cf`

### `buildFormPayload()` — Line 1048
Assembles payload for `saveSrtForm()`:
- Parent fields: item, warehouse, dates, user_remark
- Batches array: batch_no, item_code, warehouse, UOMs, conversion_factor, current_stock, qty_found, is_counted

### Save vs Submit
- **Save** (`saveForm`) — calls `saveSrtForm(payload, name)`, stays on form
- **Submit** (`submitForm`) — saves first if needed, then calls `submitSrtForm(name)`, navigates to dashboard
- After submit, checks `workflow_state === 'Approved By System'` for auto-approve toast

## §11. History (lines 1079–1136)

- Admins/Super Admins: `getAllSrtHistory(100, 0)` — all SRTs
- Regular users: `getSrtHistory(100, 0)` — own SRTs only
- Cards show: item, name, warehouse, date, status pill
- Cancelled docs: separate `pill-cancelled` styling
- Click opens `viewSrt(name)` modal

## Dependencies
- Calls: All functions in `Auth.gs` and `FrappeProxy.gs` via `callServer()`
- DOM: All element IDs defined in `index.html`
- Styles: All CSS classes defined in `styles.html`
